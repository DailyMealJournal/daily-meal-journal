<b>Daily Meal Journal</b>

  It is an application which aims provide users with a satisfying web experience of tracking down their daily food intake by calories in varied quantities.


Updated Meal journal

