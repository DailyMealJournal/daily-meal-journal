package project.controller.admin;

import api.controller.*;
import org.slim3.controller.Navigation;

/**
 * Admin/CRUD Screen Update controller.
 * @author <name here>
 *
 */
public class UpdateController extends APIController {

    @Override
    protected Navigation run() throws Exception {

        return null;
    }

}
