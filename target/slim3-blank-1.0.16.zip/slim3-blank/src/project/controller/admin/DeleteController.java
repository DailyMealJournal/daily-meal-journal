package project.controller.admin;

import api.controller.*;
import org.slim3.controller.Navigation;

/**
 * Admin/CRUD Screen Delete controller.
 * @author <name here>
 *
 */
public class DeleteController extends APIController {

    @Override
    protected Navigation run() throws Exception {
        
        return null;
    }

}
