package project.controller.meal_management;

import api.controller.*;
import org.slim3.controller.Navigation;

/**
 * Main Screen Add controller.
 * @author <name here>
 *
 */
public class InsertController extends APIController {

    @Override
    protected Navigation run() throws Exception {
        // TODO Auto-generated method stub
        return null;
    }

}
