meal_management.controller('AllController', ['$scope', function($scope) {

}]);